[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

[![GPLv3 license](https://img.shields.io/badge/License-GPLv3-blue.svg)](http://perso.crans.org/besson/LICENSE.html) [![Open Source Love svg3](https://badges.frapsoft.com/os/v3/open-source.svg?v=103)](https://github.com/dalunacrobate/daprofiler)

**FR** : A but educatif seulement.<br />
**EN** : For educational purposes only.

# BioAnalyzer
**EN** BioAnalyzer is a module that allows you to extract personnals informations from an instagram profile bio such as : Religion, Hobbies, Ethnicity, Emails, Paypal.me/, Snapchat, Twitter, Best Friends, Age, Location, Love Relationship, Love Relationship date, Facebooks, Astrologic Sign, Sexuality.

**FR** BioAnalyzer est un module qui vous permet d'extraire les informations personnelles d'un profil instagram via sa bio telles que : Religion, Hobbies, Origines ethniques, Emails, Paypal.me/, Snapchat, Twitter, Meilleurs amis, Age, Localisation (Ville, Pays), Situation amoureuse, Durée de la situation amoureuse, Facebooks, Signes astro, Sexualité.

## Demo
![alt text](https://i.ibb.co/Nxbw0hq/Capture.png)

## Contact
Mail : _daluna_pro@protonmail.ch_.

## Contributions
All Suggestions/Contributions are welcome.
